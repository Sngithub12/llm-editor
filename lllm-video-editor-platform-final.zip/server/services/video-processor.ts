import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

export interface VideoProcessingOptions {
  inputPath: string;
  outputPath: string;
  subtitles?: Array<{
    startTime: number;
    endTime: number;
    text: string;
    language: string;
  }>;
  styleSettings?: {
    colorPalette: string;
    visualEffects: string[];
    transitionStyle: string;
  };
  audioPath?: string;
  exportSettings?: {
    quality: string;
    format: string;
    frameRate: number;
  };
}

export class VideoProcessor {
  private static ensureDirectoryExists(filePath: string): void {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  static async processVideo(options: VideoProcessingOptions): Promise<string> {
    return new Promise((resolve, reject) => {
      VideoProcessor.ensureDirectoryExists(options.outputPath);
      
      const ffmpegArgs = [
        '-i', options.inputPath,
      ];

      // Add audio overlay if provided
      if (options.audioPath && fs.existsSync(options.audioPath)) {
        ffmpegArgs.push('-i', options.audioPath);
        ffmpegArgs.push('-c:v', 'copy', '-c:a', 'aac', '-map', '0:v:0', '-map', '1:a:0');
      }

      // Build filter chain for video effects
      const filters: string[] = [];

      // Add subtitle overlay
      if (options.subtitles && options.subtitles.length > 0) {
        const subtitleFilter = VideoProcessor.createSubtitleFilter(options.subtitles, options.styleSettings);
        filters.push(subtitleFilter);
      }

      // Apply visual effects
      if (options.styleSettings?.visualEffects && options.styleSettings.visualEffects.length > 0) {
        const effectsFilter = VideoProcessor.createEffectsFilter(options.styleSettings);
        if (effectsFilter !== 'null') {
          filters.push(effectsFilter);
        }
      }

      // Apply combined filters
      if (filters.length > 0) {
        ffmpegArgs.push('-vf', filters.join(','));
      }

      // Set output quality and format
      if (options.exportSettings) {
        const { quality, frameRate } = options.exportSettings;
        
        if (quality === '4K') {
          ffmpegArgs.push('-s', '3840x2160');
        } else if (quality === '1080p') {
          ffmpegArgs.push('-s', '1920x1080');
        } else if (quality === '720p') {
          ffmpegArgs.push('-s', '1280x720');
        }
        
        ffmpegArgs.push('-r', frameRate.toString());
      }

      ffmpegArgs.push('-y', options.outputPath);

      const ffmpeg = spawn('ffmpeg', ffmpegArgs);

      let errorOutput = '';

      ffmpeg.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });

      ffmpeg.on('close', (code) => {
        if (code === 0) {
          resolve(options.outputPath);
        } else {
          reject(new Error(`FFmpeg process failed with code ${code}: ${errorOutput}`));
        }
      });

      ffmpeg.on('error', (error) => {
        reject(new Error(`Failed to start FFmpeg: ${error.message}`));
      });
    });
  }

  private static createSubtitleFilter(subtitles: Array<{
    startTime: number;
    endTime: number;
    text: string;
    language: string;
  }>, styleSettings?: { colorPalette: string }): string {
    const primaryLanguageSubtitles = subtitles.filter(sub => sub.language === 'en');
    const color = styleSettings?.colorPalette || '#FFFFFF';
    
    const drawTextFilters = primaryLanguageSubtitles.map(subtitle => {
      const escapedText = subtitle.text.replace(/'/g, "\\'").replace(/:/g, "\\:");
      return `drawtext=text='${escapedText}':fontcolor=${color}:fontsize=24:x=(w-text_w)/2:y=h-th-50:enable='between(t,${subtitle.startTime},${subtitle.endTime})'`;
    });

    return drawTextFilters.join(',');
  }

  private static createEffectsFilter(styleSettings: {
    colorPalette: string;
    visualEffects: string[];
    transitionStyle: string;
  }): string {
    const effects: string[] = [];

    if (styleSettings.visualEffects.includes('blur')) {
      effects.push('boxblur=2:1');
    }

    if (styleSettings.visualEffects.includes('colorGrading')) {
      effects.push('eq=brightness=0.1:contrast=1.2:saturation=1.1');
    }

    if (styleSettings.visualEffects.includes('gradientOverlay')) {
      effects.push('curves=vintage');
    }

    if (styleSettings.visualEffects.includes('particleEffects')) {
      effects.push('noise=alls=20:allf=t+u');
    }

    // Apply color palette effects based on selection
    if (styleSettings.colorPalette === 'blue') {
      effects.push('colorbalance=rs=-0.3:gs=0.1:bs=0.3');
    } else if (styleSettings.colorPalette === 'purple') {
      effects.push('colorbalance=rs=0.2:gs=-0.1:bs=0.3');
    } else if (styleSettings.colorPalette === 'green') {
      effects.push('colorbalance=rs=-0.2:gs=0.3:bs=-0.1');
    }

    return effects.join(',') || 'null';
  }

  static async generateVideoFromScript(
    script: string,
    audioPath: string,
    outputPath: string,
    options?: {
      duration: number;
      styleSettings?: VideoProcessingOptions['styleSettings'];
      exportSettings?: VideoProcessingOptions['exportSettings'];
    }
  ): Promise<string> {
    return new Promise((resolve, reject) => {
      VideoProcessor.ensureDirectoryExists(outputPath);
      
      const duration = options?.duration || 30;
      
      // Create a simple video from audio with generated visuals
      const ffmpegArgs = [
        '-f', 'lavfi',
        '-i', `color=c=black:size=1920x1080:duration=${duration}`,
        '-i', audioPath,
        '-c:v', 'libx264',
        '-c:a', 'aac',
        '-shortest',
        '-y', outputPath
      ];

      const ffmpeg = spawn('ffmpeg', ffmpegArgs);

      let errorOutput = '';

      ffmpeg.stderr.on('data', (data) => {
        errorOutput += data.toString();
      });

      ffmpeg.on('close', (code) => {
        if (code === 0) {
          resolve(outputPath);
        } else {
          reject(new Error(`FFmpeg process failed with code ${code}: ${errorOutput}`));
        }
      });

      ffmpeg.on('error', (error) => {
        reject(new Error(`Failed to start FFmpeg: ${error.message}`));
      });
    });
  }
}
