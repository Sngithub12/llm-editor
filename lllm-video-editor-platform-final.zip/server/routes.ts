import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { generateVideoScript, generateSubtitles } from "./services/openai";
import { VideoProcessor } from "./services/video-processor";
import { insertVideoProjectSchema, updateVideoProjectSchema } from "@shared/schema";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only video files are allowed'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Create new video project
  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertVideoProjectSchema.parse(req.body);
      const project = await storage.createVideoProject(projectData);
      res.json(project);
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid project data" 
      });
    }
  });

  // Get video project
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getVideoProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get project" 
      });
    }
  });

  // Update video project
  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = updateVideoProjectSchema.parse(req.body);
      const project = await storage.updateVideoProject(id, updates);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid update data" 
      });
    }
  });

  // Upload video file
  app.post("/api/upload", upload.single('video'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No video file uploaded" });
      }

      const videoPath = req.file.path;
      const originalName = req.file.originalname;
      
      res.json({
        path: videoPath,
        originalName,
        size: req.file.size,
      });
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Upload failed" 
      });
    }
  });

  // Generate script using AI
  app.post("/api/generate-script", async (req, res) => {
    try {
      const { topic, duration, tone, style } = req.body;
      
      if (!topic || !duration || !tone || !style) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const result = await generateVideoScript({ topic, duration, tone, style });
      res.json(result);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Script generation failed" 
      });
    }
  });

  // Generate subtitles
  app.post("/api/generate-subtitles", async (req, res) => {
    try {
      const { script, languages, duration } = req.body;
      
      if (!script || !languages || !duration) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const subtitles = await generateSubtitles({ script, languages, duration });
      res.json({ subtitles });
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Subtitle generation failed" 
      });
    }
  });

  // Generate voiceover (mock implementation - would integrate with TTS service)
  app.post("/api/generate-voiceover", async (req, res) => {
    try {
      const { script, voiceId, speed, pitch, language } = req.body;
      
      if (!script) {
        return res.status(400).json({ message: "Script is required" });
      }

      // Mock voiceover generation - in production, integrate with TTS service
      const audioPath = path.join(uploadDir, `voiceover_${Date.now()}.mp3`);
      
      // For now, create a placeholder audio file
      fs.writeFileSync(audioPath, Buffer.from('mock audio data'));
      
      res.json({
        audioPath,
        duration: script.split(' ').length * 0.5, // Rough estimate
      });
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Voiceover generation failed" 
      });
    }
  });

  // Process and export video
  app.post("/api/export-video", async (req, res) => {
    try {
      const { 
        projectId, 
        inputVideoPath, 
        subtitles, 
        styleSettings, 
        audioPath, 
        exportSettings 
      } = req.body;

      // Always create a new project for each export
      const project = await storage.createVideoProject({
        name: `Video Export ${Date.now()}`,
        type: req.body.workflowType || "generate",
        status: "processing",
        script: req.body.script || null,
        subtitles: req.body.subtitles || null,
        styleSettings: req.body.styleSettings || null,
        userId: 1
      });

      // Update project status to processing
      await storage.updateVideoProject(project.id, { status: 'processing' });

      const outputPath = path.join(uploadDir, `exported_${project.id}_${Date.now()}.mp4`);

      try {
        let processedVideoPath: string;

        if (project.type === 'generate' && project.script && audioPath) {
          // Generate video from script and audio
          processedVideoPath = await VideoProcessor.generateVideoFromScript(
            project.script,
            audioPath,
            outputPath,
            {
              duration: 30, // Default duration
              styleSettings,
              exportSettings,
            }
          );
        } else if (inputVideoPath) {
          // Process existing video
          processedVideoPath = await VideoProcessor.processVideo({
            inputPath: inputVideoPath,
            outputPath,
            subtitles,
            styleSettings,
            audioPath,
            exportSettings,
          });
        } else {
          throw new Error("No input video or script available for processing");
        }

        // Update project with processed video path
        const updatedProject = await storage.updateVideoProject(project.id, {
          status: 'completed',
          processedVideoPath,
        });

        res.json({
          success: true,
          videoPath: processedVideoPath,
          project: updatedProject,
        });
      } catch (processingError) {
        // Update project status to failed
        await storage.updateVideoProject(project.id, { status: 'failed' });
        throw processingError;
      }
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Video export failed" 
      });
    }
  });

  // Download processed video
  app.get("/api/download/:filename", (req, res) => {
    try {
      const filename = req.params.filename;
      const filePath = path.join(uploadDir, filename);

      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found" });
      }

      // Set proper headers for video download
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'video/mp4');
      res.download(filePath, filename, (err) => {
        if (err) {
          console.error('Download error:', err);
          if (!res.headersSent) {
            res.status(500).json({ message: "Download failed" });
          }
        }
      });
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Download failed" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
