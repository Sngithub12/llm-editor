import { apiRequest } from "./queryClient";

export interface ScriptGenerationRequest {
  topic: string;
  duration: string;
  tone: string;
  style: string;
}

export interface SubtitleGenerationRequest {
  script: string;
  languages: string[];
  duration: number;
}

export interface VoiceoverGenerationRequest {
  script: string;
  voiceId: string;
  speed: number;
  pitch: number;
  language: string;
}

export interface VideoExportRequest {
  projectId: number;
  inputVideoPath?: string;
  subtitles?: Array<{
    startTime: number;
    endTime: number;
    text: string;
    language: string;
  }>;
  styleSettings?: {
    colorPalette: string;
    visualEffects: string[];
    transitionStyle: string;
  };
  audioPath?: string;
  exportSettings: {
    quality: string;
    format: string;
    frameRate: number;
    compression: string;
  };
}

export const videoApi = {
  generateScript: async (data: ScriptGenerationRequest) => {
    const response = await apiRequest('POST', '/api/generate-script', data);
    return response.json();
  },

  generateSubtitles: async (data: SubtitleGenerationRequest) => {
    const response = await apiRequest('POST', '/api/generate-subtitles', data);
    return response.json();
  },

  generateVoiceover: async (data: VoiceoverGenerationRequest) => {
    const response = await apiRequest('POST', '/api/generate-voiceover', data);
    return response.json();
  },

  uploadVideo: async (file: File) => {
    const formData = new FormData();
    formData.append('video', file);
    
    const response = await apiRequest('POST', '/api/upload', formData);
    return response.json();
  },

  exportVideo: async (data: VideoExportRequest) => {
    const response = await apiRequest('POST', '/api/export-video', data);
    return response.json();
  },

  downloadVideo: (filename: string) => {
    window.open(`/api/download/${filename}`, '_blank');
  },
};
