import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Video, Upload, Wand2, HelpCircle, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import VideoUpload from "@/components/video-upload";

export default function Home() {
  const [, setLocation] = useLocation();
  const [showUploadModal, setShowUploadModal] = useState(false);

  const handleGenerateVideo = () => {
    setLocation("/workflow/generate");
  };

  const handleUploadComplete = (filePath: string) => {
    setShowUploadModal(false);
    setLocation("/workflow/edit", { state: { uploadedVideoPath: filePath } });
  };

  return (
    <div className="min-h-screen bg-dark">
      {/* Navigation */}
      <nav className="bg-[hsl(var(--surface))] border-b border-[hsl(var(--surface-light))] px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Video className="text-primary text-2xl" />
            <h1 className="text-xl font-bold">LLLM Video Editing</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="text-slate-300 hover:text-white">
              <HelpCircle className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-slate-300 hover:text-white">
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="flex flex-col items-center justify-center min-h-[80vh] px-6">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-6xl font-bold mb-4 gradient-text">
            LLLM Video Editing
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Create stunning videos with AI-powered editing tools. Generate from scratch or enhance existing content.
          </p>
        </motion.div>

        {/* Main Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-6 w-full max-w-2xl">
          {/* Generate Video Button */}
          <motion.div
            className="flex-1"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Button
              onClick={handleGenerateVideo}
              className="group relative w-full bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 text-white py-8 px-8 rounded-2xl transition-all duration-300 transform hover:scale-105 hover:shadow-2xl animate-pulse-slow h-auto"
            >
              <div className="flex flex-col items-center space-y-4">
                <div className="bg-white/20 p-4 rounded-full group-hover:bg-white/30 transition-colors">
                  <Wand2 className="h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">Generate Video</h3>
                  <p className="text-sm opacity-90">Create videos from AI-generated scripts</p>
                </div>
              </div>
              <div className="absolute inset-0 bg-white/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </Button>
          </motion.div>

          {/* Upload Video Button */}
          <motion.div
            className="flex-1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Button
              onClick={() => setShowUploadModal(true)}
              className="group relative w-full bg-gradient-to-r from-accent to-emerald-600 hover:from-accent/90 hover:to-emerald-600/90 text-white py-8 px-8 rounded-2xl transition-all duration-300 transform hover:scale-105 hover:shadow-2xl animate-bounce-slow h-auto"
            >
              <div className="flex flex-col items-center space-y-4">
                <div className="bg-white/20 p-4 rounded-full group-hover:bg-white/30 transition-colors">
                  <Upload className="h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">Upload Video</h3>
                  <p className="text-sm opacity-90">Edit and enhance existing videos</p>
                </div>
              </div>
              <div className="absolute inset-0 bg-white/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Upload Modal */}
      <VideoUpload
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onUploadComplete={handleUploadComplete}
      />
    </div>
  );
}
