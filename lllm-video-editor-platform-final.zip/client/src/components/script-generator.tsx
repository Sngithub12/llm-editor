import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Wand2, Copy, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ScriptGeneratorProps {
  workflowType: string;
  projectData: any;
  onStepData: (stepId: string, data: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isFirstStep: boolean;
  isLastStep: boolean;
}

const toneOptions = [
  { value: "professional", label: "Professional", description: "Business & Corporate" },
  { value: "casual", label: "Casual", description: "Friendly & Conversational" },
  { value: "educational", label: "Educational", description: "Informative & Clear" },
  { value: "entertaining", label: "Entertaining", description: "Fun & Engaging" },
];

export default function ScriptGenerator({ 
  projectData, 
  onStepData, 
  onNext, 
  onPrevious, 
  isFirstStep 
}: ScriptGeneratorProps) {
  const [topic, setTopic] = useState(projectData.script?.topic || "");
  const [duration, setDuration] = useState(projectData.script?.duration || "1 minute");
  const [tone, setTone] = useState(projectData.script?.tone || "");
  const [style, setStyle] = useState(projectData.script?.style || "");
  const [generatedScript, setGeneratedScript] = useState(projectData.script?.content || "");
  
  const { toast } = useToast();

  const generateScriptMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/generate-script', {
        topic,
        duration,
        tone,
        style: style || tone,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedScript(data.script);
      toast({
        title: "Script generated",
        description: "Your AI-generated script is ready!",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation failed",
        description: error instanceof Error ? error.message : "Failed to generate script",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!topic.trim()) {
      toast({
        title: "Topic required",
        description: "Please enter a video topic to generate a script.",
        variant: "destructive",
      });
      return;
    }

    if (!tone) {
      toast({
        title: "Tone required",
        description: "Please select a tone for your video.",
        variant: "destructive",
      });
      return;
    }

    generateScriptMutation.mutate();
  };

  const handleCopyScript = () => {
    navigator.clipboard.writeText(generatedScript);
    toast({
      title: "Script copied",
      description: "The script has been copied to your clipboard.",
    });
  };

  const handleNext = () => {
    if (!generatedScript.trim()) {
      toast({
        title: "Script required",
        description: "Please generate a script before continuing.",
        variant: "destructive",
      });
      return;
    }

    onStepData('script', {
      topic,
      duration,
      tone,
      style: style || tone,
      content: generatedScript,
    });
    onNext();
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-4">AI Script Generator</h2>
        <p className="text-slate-300">Generate compelling video scripts using AI</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div>
            <Label htmlFor="topic" className="text-sm font-medium mb-2">Video Topic</Label>
            <Input
              id="topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Enter your video topic..."
              className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))] focus:border-primary"
            />
          </div>
          
          <div>
            <Label htmlFor="duration" className="text-sm font-medium mb-2">Video Duration</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))] focus:border-primary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30 seconds">30 seconds</SelectItem>
                <SelectItem value="1 minute">1 minute</SelectItem>
                <SelectItem value="2 minutes">2 minutes</SelectItem>
                <SelectItem value="5 minutes">5 minutes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm font-medium mb-2">Tone & Style</Label>
            <div className="grid grid-cols-1 gap-3">
              {toneOptions.map((option) => (
                <Card
                  key={option.value}
                  className={`cursor-pointer transition-colors ${
                    tone === option.value
                      ? 'border-primary bg-primary/10'
                      : 'border-[hsl(var(--surface-light))] hover:border-primary bg-[hsl(var(--surface))]'
                  }`}
                  onClick={() => setTone(option.value)}
                >
                  <CardContent className="p-3">
                    <div className="font-medium">{option.label}</div>
                    <div className="text-sm text-slate-400">{option.description}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Button
            onClick={handleGenerate}
            disabled={generateScriptMutation.isPending}
            className="w-full bg-primary hover:bg-primary/90"
          >
            {generateScriptMutation.isPending ? (
              <>
                <div className="processing-spinner mr-2 h-4 w-4" />
                Generating...
              </>
            ) : (
              <>
                <Wand2 className="mr-2 h-4 w-4" />
                Generate Script
              </>
            )}
          </Button>
        </div>

        <div>
          <Label htmlFor="script" className="text-sm font-medium mb-2">Generated Script</Label>
          <Textarea
            id="script"
            value={generatedScript}
            onChange={(e) => setGeneratedScript(e.target.value)}
            rows={15}
            placeholder="Your AI-generated script will appear here..."
            className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))] focus:border-primary resize-none"
          />
          
          <div className="flex justify-between mt-4">
            <Button
              variant="ghost"
              onClick={handleCopyScript}
              disabled={!generatedScript}
              className="text-slate-400 hover:text-white"
            >
              <Copy className="mr-2 h-4 w-4" />
              Copy Script
            </Button>
            <Button
              variant="ghost"
              onClick={handleGenerate}
              disabled={generateScriptMutation.isPending}
              className="text-slate-400 hover:text-white"
            >
              <RotateCcw className="mr-2 h-4 w-4" />
              Regenerate
            </Button>
          </div>
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <Button
          variant="ghost"
          onClick={onPrevious}
          disabled={isFirstStep}
          className="text-slate-400 hover:text-white"
        >
          Back
        </Button>
        <Button
          onClick={handleNext}
          className="bg-primary hover:bg-primary/90"
        >
          Continue to Subtitles
        </Button>
      </div>
    </div>
  );
}
