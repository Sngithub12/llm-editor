import { users, videoProjects, type User, type InsertUser, type VideoProject, type InsertVideoProject, type UpdateVideoProject } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getVideoProject(id: number): Promise<VideoProject | undefined>;
  createVideoProject(project: InsertVideoProject): Promise<VideoProject>;
  updateVideoProject(id: number, updates: UpdateVideoProject): Promise<VideoProject | undefined>;
  getUserVideoProjects(userId?: number): Promise<VideoProject[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private videoProjects: Map<number, VideoProject>;
  private currentUserId: number;
  private currentProjectId: number;

  constructor() {
    this.users = new Map();
    this.videoProjects = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getVideoProject(id: number): Promise<VideoProject | undefined> {
    return this.videoProjects.get(id);
  }

  async createVideoProject(insertProject: InsertVideoProject): Promise<VideoProject> {
    const id = this.currentProjectId++;
    const now = new Date();
    const project: VideoProject = {
      ...insertProject,
      script: insertProject.script || null,
      subtitles: insertProject.subtitles || null,
      styleSettings: insertProject.styleSettings || null,
      voiceSettings: insertProject.voiceSettings || null,
      exportSettings: insertProject.exportSettings || null,
      id,
      createdAt: now,
      updatedAt: now,
    };
    this.videoProjects.set(id, project);
    return project;
  }

  async updateVideoProject(id: number, updates: UpdateVideoProject): Promise<VideoProject | undefined> {
    const existing = this.videoProjects.get(id);
    if (!existing) return undefined;

    const updated: VideoProject = {
      ...existing,
      ...updates,
      updatedAt: new Date(),
    };
    this.videoProjects.set(id, updated);
    return updated;
  }

  async getUserVideoProjects(userId?: number): Promise<VideoProject[]> {
    return Array.from(this.videoProjects.values()).filter(
      (project) => !userId || project.userId === userId
    );
  }
}

export const storage = new MemStorage();
