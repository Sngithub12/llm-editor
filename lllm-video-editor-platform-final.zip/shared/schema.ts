import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const videoProjects = pgTable("video_projects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'generate' or 'edit'
  status: text("status").notNull().default('draft'), // 'draft', 'processing', 'completed', 'failed'
  originalVideoPath: text("original_video_path"),
  processedVideoPath: text("processed_video_path"),
  script: text("script"),
  subtitles: jsonb("subtitles").$type<Array<{
    startTime: number;
    endTime: number;
    text: string;
    language: string;
  }>>(),
  styleSettings: jsonb("style_settings").$type<{
    colorPalette: string;
    visualEffects: string[];
    transitionStyle: string;
    template: string;
  }>(),
  voiceSettings: jsonb("voice_settings").$type<{
    voiceId: string;
    speed: number;
    pitch: number;
    language: string;
  }>(),
  exportSettings: jsonb("export_settings").$type<{
    quality: string;
    format: string;
    frameRate: number;
    compression: string;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertVideoProjectSchema = createInsertSchema(videoProjects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateVideoProjectSchema = insertVideoProjectSchema.partial();

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type VideoProject = typeof videoProjects.$inferSelect;
export type InsertVideoProject = z.infer<typeof insertVideoProjectSchema>;
export type UpdateVideoProject = z.infer<typeof updateVideoProjectSchema>;
