import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Plus, Edit2, Volume2, Maximize } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface SubtitleEditorProps {
  workflowType: string;
  projectData: any;
  onStepData: (stepId: string, data: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isFirstStep: boolean;
  isLastStep: boolean;
}

const languageOptions = [
  { code: 'en', name: 'English', isPrimary: true, flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
];

const colorOptions = [
  { value: '#FFFFFF', name: 'White', className: 'bg-white' },
  { value: '#FFFF00', name: 'Yellow', className: 'bg-yellow-400' },
  { value: '#FF0000', name: 'Red', className: 'bg-red-500' },
  { value: '#00FF00', name: 'Green', className: 'bg-green-500' },
];

export default function SubtitleEditor({ 
  workflowType,
  projectData, 
  onStepData, 
  onNext, 
  onPrevious, 
  isFirstStep 
}: SubtitleEditorProps) {
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>(['en']);
  const [fontSize, setFontSize] = useState([18]);
  const [textColor, setTextColor] = useState('#FFFFFF');
  const [position, setPosition] = useState('bottom-center');
  const [subtitles, setSubtitles] = useState<Array<{
    startTime: number;
    endTime: number;
    text: string;
    language: string;
  }>>([]);

  const { toast } = useToast();

  useEffect(() => {
    if (projectData.subtitles) {
      setSubtitles(projectData.subtitles.subtitles || []);
      setSelectedLanguages(projectData.subtitles.languages || ['en']);
      setTextColor(projectData.subtitles.textColor || '#FFFFFF');
      setFontSize([projectData.subtitles.fontSize || 18]);
      setPosition(projectData.subtitles.position || 'bottom-center');
    }
  }, [projectData.subtitles]);

  const generateSubtitlesMutation = useMutation({
    mutationFn: async () => {
      const script = projectData.script?.content || "Sample video content for subtitle generation.";
      const duration = 30; // Default duration
      
      const response = await apiRequest('POST', '/api/generate-subtitles', {
        script,
        languages: selectedLanguages,
        duration,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setSubtitles(data.subtitles);
      toast({
        title: "Subtitles generated",
        description: "Multi-language subtitles have been created for your video.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation failed",
        description: error instanceof Error ? error.message : "Failed to generate subtitles",
        variant: "destructive",
      });
    },
  });

  const handleLanguageChange = (languageCode: string, checked: boolean) => {
    if (checked) {
      setSelectedLanguages(prev => [...prev, languageCode]);
    } else {
      if (languageCode === 'en') {
        toast({
          title: "Cannot remove English",
          description: "English is required as the primary language.",
          variant: "destructive",
        });
        return;
      }
      setSelectedLanguages(prev => prev.filter(lang => lang !== languageCode));
    }
  };

  const handleSubtitleEdit = (index: number, newText: string) => {
    const updated = [...subtitles];
    updated[index] = { ...updated[index], text: newText };
    setSubtitles(updated);
  };

  const addSubtitle = () => {
    const newSubtitle = {
      startTime: subtitles.length * 5,
      endTime: (subtitles.length + 1) * 5,
      text: "New subtitle text",
      language: 'en'
    };
    setSubtitles([...subtitles, newSubtitle]);
  };

  const handleNext = () => {
    if (subtitles.length === 0) {
      toast({
        title: "No subtitles",
        description: "Please generate subtitles before continuing.",
        variant: "destructive",
      });
      return;
    }

    onStepData('subtitles', {
      subtitles,
      languages: selectedLanguages,
      textColor,
      fontSize: fontSize[0],
      position,
    });
    onNext();
  };

  const englishSubtitles = subtitles.filter(sub => sub.language === 'en');

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-4">Subtitle Configuration</h2>
        <p className="text-slate-300">Add multi-language subtitles to your video</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Video Preview */}
        <div className="lg:col-span-2">
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Video Preview</h3>
              <div className="video-preview bg-gradient-to-br from-blue-900 via-purple-900 to-pink-900">
                <div className="text-center">
                  <div className="h-16 w-16 bg-white/50 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                    <div className="h-0 w-0 border-l-[16px] border-l-white border-y-[12px] border-y-transparent ml-1"></div>
                  </div>
                  <p className="text-white/70 mb-2">Video Preview</p>
                  <p className="text-white/50 text-sm">Subtitles will appear below</p>
                </div>
                
                {/* Language indicators */}
                <div className="absolute top-4 right-4 flex flex-wrap gap-1">
                  {selectedLanguages.map((lang) => {
                    const langData = languageOptions.find(l => l.code === lang);
                    return (
                      <span key={lang} className="bg-black/50 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                        <span>{langData?.flag}</span>
                        <span>{langData?.name}</span>
                      </span>
                    );
                  })}
                </div>
                
                {/* Subtitle overlay */}
                <div className="absolute bottom-4 left-4 right-4">
                  <div 
                    className="bg-black/80 text-center py-2 px-4 rounded transition-all duration-300 border border-white/20"
                    style={{ 
                      color: textColor,
                      fontSize: `${fontSize[0]}px`,
                      fontFamily: 'Arial, sans-serif',
                      textShadow: '0 1px 2px rgba(0,0,0,0.8)'
                    }}
                  >
                    {englishSubtitles[0]?.text || "Welcome to our AI video editing platform. Create stunning videos with ease."}
                  </div>
                  
                  {/* Show multiple language previews if selected */}
                  {selectedLanguages.length > 1 && (
                    <div className="mt-2 flex gap-2 text-xs">
                      {selectedLanguages.slice(1, 3).map((lang) => {
                        const langData = languageOptions.find(l => l.code === lang);
                        return (
                          <div key={lang} className="bg-black/60 text-white/80 px-2 py-1 rounded">
                            {langData?.flag} {langData?.name} subtitles ready
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
              
              {/* Video Controls */}
              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center space-x-4">
                  <Button variant="ghost" size="sm" className="text-white hover:text-primary">
                    <div className="h-0 w-0 border-l-[12px] border-l-white border-y-[8px] border-y-transparent"></div>
                  </Button>
                  <span className="text-sm text-slate-400">0:00 / 2:30</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm" className="text-white hover:text-primary">
                    <Volume2 className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="text-white hover:text-primary">
                    <Maximize className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subtitle Settings */}
        <div className="space-y-6">
          {/* Language Selection */}
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Language Options</h3>
              <div className="space-y-3">
                {languageOptions.map((lang) => (
                  <div key={lang.code} className="flex items-center justify-between">
                    <label className="flex items-center space-x-3 cursor-pointer">
                      <Checkbox
                        checked={selectedLanguages.includes(lang.code)}
                        onCheckedChange={(checked) => 
                          handleLanguageChange(lang.code, checked as boolean)
                        }
                      />
                      <span className="text-lg">{lang.flag}</span>
                      <span>{lang.name}</span>
                    </label>
                    {lang.isPrimary && (
                      <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded">
                        Primary
                      </span>
                    )}
                  </div>
                ))}
              </div>
              <Button
                onClick={() => generateSubtitlesMutation.mutate()}
                disabled={generateSubtitlesMutation.isPending}
                className="w-full mt-4 bg-primary hover:bg-primary/90"
              >
                {generateSubtitlesMutation.isPending ? "Generating..." : "Generate Subtitles"}
              </Button>
            </CardContent>
          </Card>

          {/* Subtitle Styling */}
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Subtitle Style</h3>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium mb-2">Font Size</Label>
                  <Slider
                    value={fontSize}
                    onValueChange={setFontSize}
                    min={12}
                    max={32}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-1">
                    <span>Small (12px)</span>
                    <span>Large (32px)</span>
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm font-medium mb-2">Text Color</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {colorOptions.map((color) => (
                      <button
                        key={color.value}
                        onClick={() => setTextColor(color.value)}
                        className={`w-8 h-8 rounded border-2 transition-colors ${
                          textColor === color.value
                            ? 'border-primary'
                            : 'border-[hsl(var(--surface-light))] hover:border-primary'
                        } ${color.className}`}
                        title={color.name}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2">Position</Label>
                  <Select value={position} onValueChange={setPosition}>
                    <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bottom-center">Bottom Center</SelectItem>
                      <SelectItem value="top-center">Top Center</SelectItem>
                      <SelectItem value="bottom-left">Bottom Left</SelectItem>
                      <SelectItem value="bottom-right">Bottom Right</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Subtitle Timeline */}
      {englishSubtitles.length > 0 && (
        <Card className="mt-8 bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Subtitle Timeline</h3>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {englishSubtitles.map((subtitle, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 bg-[hsl(var(--surface-light))] rounded-lg">
                  <span className="text-sm text-slate-400 w-20">
                    {Math.floor(subtitle.startTime)}:{String(Math.floor((subtitle.startTime % 1) * 60)).padStart(2, '0')}-
                    {Math.floor(subtitle.endTime)}:{String(Math.floor((subtitle.endTime % 1) * 60)).padStart(2, '0')}
                  </span>
                  <Input
                    value={subtitle.text}
                    onChange={(e) => handleSubtitleEdit(index, e.target.value)}
                    className="flex-1 bg-transparent border-none focus:ring-0 focus:outline-none"
                  />
                  <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                    <Edit2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
            <Button onClick={addSubtitle} variant="ghost" className="mt-4 text-primary hover:bg-primary/10">
              <Plus className="mr-2 h-4 w-4" />
              Add Subtitle
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="flex justify-between mt-8">
        <Button
          variant="ghost"
          onClick={onPrevious}
          disabled={isFirstStep}
          className="text-slate-400 hover:text-white"
        >
          Back
        </Button>
        <Button
          onClick={handleNext}
          className="bg-primary hover:bg-primary/90"
        >
          Continue to Style
        </Button>
      </div>
    </div>
  );
}
