import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { Check, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import ScriptGenerator from "@/components/script-generator";
import SubtitleEditor from "@/components/subtitle-editor";
import StyleRecommender from "@/components/style-recommender";
import VoiceoverGenerator from "@/components/voiceover-generator";
import VideoExport from "@/components/video-export";

interface WorkflowStep {
  id: string;
  title: string;
  icon: string;
  component: React.ComponentType<any>;
}

const workflows = {
  generate: [
    { id: 'script', title: 'Script Generator', icon: 'fas fa-file-alt', component: ScriptGenerator },
    { id: 'subtitles', title: 'Subtitles', icon: 'fas fa-closed-captioning', component: SubtitleEditor },
    { id: 'style', title: 'Style Recommender', icon: 'fas fa-palette', component: StyleRecommender },
    { id: 'voiceover', title: 'Voiceover', icon: 'fas fa-microphone', component: VoiceoverGenerator },
    { id: 'export', title: 'Export', icon: 'fas fa-download', component: VideoExport }
  ],
  edit: [
    { id: 'subtitles', title: 'Subtitles', icon: 'fas fa-closed-captioning', component: SubtitleEditor },
    { id: 'style', title: 'Style Recommender', icon: 'fas fa-palette', component: StyleRecommender },
    { id: 'voiceover', title: 'Voiceover', icon: 'fas fa-microphone', component: VoiceoverGenerator },
    { id: 'export', title: 'Export', icon: 'fas fa-download', component: VideoExport }
  ]
};

export default function Workflow() {
  const [match, params] = useRoute("/workflow/:type");
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(0);
  const [projectData, setProjectData] = useState<any>({});

  const workflowType = params?.type as 'generate' | 'edit';
  const steps = workflows[workflowType] || [];
  const CurrentStepComponent = steps[currentStep]?.component;

  useEffect(() => {
    if (!match || !workflowType || !workflows[workflowType]) {
      setLocation("/");
    }
  }, [match, workflowType, setLocation]);

  const handleStepData = (stepId: string, data: any) => {
    setProjectData(prev => ({
      ...prev,
      [stepId]: data
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const previousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const navigateToStep = (stepIndex: number) => {
    if (stepIndex <= currentStep) {
      setCurrentStep(stepIndex);
    }
  };

  const goHome = () => {
    setLocation("/");
  };

  if (!match || !CurrentStepComponent) {
    return null;
  }

  return (
    <div className="flex h-screen bg-dark">
      {/* Sidebar Navigation */}
      <div className="w-80 bg-[hsl(var(--surface))] border-r border-[hsl(var(--surface-light))] p-6">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={goHome}
            className="mb-4 text-slate-300 hover:text-white"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
          <h2 className="text-lg font-semibold mb-4">Workflow Progress</h2>
          
          {/* Progress Steps */}
          <div className="space-y-4">
            {steps.map((step, index) => (
              <div
                key={step.id}
                onClick={() => navigateToStep(index)}
                className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-colors ${
                  index === currentStep 
                    ? 'bg-primary/20 border border-primary/30' 
                    : index < currentStep 
                    ? 'bg-accent/20 border border-accent/30' 
                    : 'hover:bg-[hsl(var(--surface-light))]'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  index === currentStep 
                    ? 'bg-primary text-white' 
                    : index < currentStep 
                    ? 'bg-accent text-white' 
                    : 'bg-[hsl(var(--surface-light))] text-slate-400'
                }`}>
                  {index < currentStep ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <i className={`${step.icon} text-sm`}></i>
                  )}
                </div>
                <span className={`font-medium ${
                  index <= currentStep ? 'text-white' : 'text-slate-400'
                }`}>
                  {step.title}
                </span>
                {index < currentStep && (
                  <Check className="h-4 w-4 text-accent ml-auto" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          <CurrentStepComponent
            workflowType={workflowType}
            projectData={projectData}
            onStepData={handleStepData}
            onNext={nextStep}
            onPrevious={previousStep}
            isFirstStep={currentStep === 0}
            isLastStep={currentStep === steps.length - 1}
          />
        </div>
      </div>
    </div>
  );
}
