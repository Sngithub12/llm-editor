import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface StyleRecommenderProps {
  workflowType: string;
  projectData: any;
  onStepData: (stepId: string, data: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isFirstStep: boolean;
  isLastStep: boolean;
}

const colorPalettes = [
  { id: 'blue', name: 'Ocean Blue', colors: ['#3B82F6', '#1D4ED8', '#1E3A8A'] },
  { id: 'purple', name: 'Royal Purple', colors: ['#8B5CF6', '#7C3AED', '#6D28D9'] },
  { id: 'green', name: 'Forest Green', colors: ['#10B981', '#059669', '#047857'] },
  { id: 'orange', name: 'Sunset Orange', colors: ['#F59E0B', '#D97706', '#B45309'] },
  { id: 'pink', name: 'Cherry Blossom', colors: ['#EC4899', '#DB2777', '#BE185D'] },
  { id: 'teal', name: 'Ocean Teal', colors: ['#14B8A6', '#0D9488', '#0F766E'] },
];

const visualEffects = [
  { id: 'blur', name: 'Blur Background', description: 'Add background blur effect' },
  { id: 'colorGrading', name: 'Color Grading', description: 'Enhanced color correction' },
  { id: 'gradientOverlay', name: 'Gradient Overlay', description: 'Add gradient overlay' },
  { id: 'particleEffects', name: 'Particle Effects', description: 'Add particle animations' },
];

const styleTemplates = [
  { id: 'corporate', name: 'Modern Corporate', description: 'Clean, professional styling' },
  { id: 'creative', name: 'Creative Gradient', description: 'Vibrant, artistic approach' },
  { id: 'minimalist', name: 'Minimalist', description: 'Simple, elegant design' },
];

export default function StyleRecommender({ 
  projectData, 
  onStepData, 
  onNext, 
  onPrevious, 
  isFirstStep 
}: StyleRecommenderProps) {
  const [selectedPalette, setSelectedPalette] = useState('purple');
  const [selectedEffects, setSelectedEffects] = useState<string[]>(['gradientOverlay']);
  const [transitionStyle, setTransitionStyle] = useState('fade');
  const [animationSpeed, setAnimationSpeed] = useState('normal');
  const [selectedTemplate, setSelectedTemplate] = useState('creative');

  const { toast } = useToast();

  useEffect(() => {
    if (projectData.style) {
      setSelectedPalette(projectData.style.colorPalette || 'purple');
      setSelectedEffects(projectData.style.visualEffects || ['gradientOverlay']);
      setTransitionStyle(projectData.style.transitionStyle || 'fade');
      setAnimationSpeed(projectData.style.animationSpeed || 'normal');
      setSelectedTemplate(projectData.style.template || 'creative');
    }
  }, [projectData.style]);

  const handleEffectChange = (effectId: string, checked: boolean) => {
    if (checked) {
      setSelectedEffects(prev => [...prev, effectId]);
    } else {
      setSelectedEffects(prev => prev.filter(id => id !== effectId));
    }
  };

  const applyColorPalette = (paletteId: string) => {
    setSelectedPalette(paletteId);
    
    // Update the visual preview immediately
    const selectedPaletteData = colorPalettes.find(p => p.id === paletteId);
    
    toast({
      title: "Color palette applied",
      description: `${selectedPaletteData?.name} palette will be applied to your video with enhanced color effects.`,
    });
  };

  const handleNext = () => {
    const styleData = {
      colorPalette: selectedPalette,
      visualEffects: selectedEffects,
      transitionStyle,
      animationSpeed,
      template: selectedTemplate,
    };

    onStepData('style', styleData);
    onNext();
  };

  const selectedPaletteData = colorPalettes.find(p => p.id === selectedPalette);
  const gradientStyle = selectedPaletteData 
    ? `linear-gradient(135deg, ${selectedPaletteData.colors[0]}, ${selectedPaletteData.colors[2]})`
    : 'linear-gradient(135deg, #8B5CF6, #6D28D9)';

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-4">Style Recommender</h2>
        <p className="text-slate-300">Choose visual styles and color palettes for your video</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Video Preview */}
        <div className="lg:col-span-2">
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Style Preview</h3>
              <div 
                className="rounded-lg aspect-video flex items-center justify-center relative transition-all duration-500 overflow-hidden"
                style={{ background: gradientStyle }}
              >
                {/* Background pattern based on selected effects */}
                {selectedEffects.includes('particleEffects') && (
                  <div className="absolute inset-0 opacity-30">
                    {Array.from({ length: 20 }, (_, i) => (
                      <div
                        key={i}
                        className="absolute w-1 h-1 bg-white rounded-full animate-pulse"
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`,
                          animationDelay: `${Math.random() * 2}s`,
                          animationDuration: `${2 + Math.random() * 2}s`
                        }}
                      />
                    ))}
                  </div>
                )}
                
                <div className="text-center z-10">
                  <div className={`h-16 w-16 bg-white/50 rounded-full flex items-center justify-center mx-auto mb-4 ${
                    selectedEffects.includes('blur') ? 'backdrop-blur-sm' : ''
                  }`}>
                    <div className="h-0 w-0 border-l-[16px] border-l-white border-y-[12px] border-y-transparent ml-1"></div>
                  </div>
                  <p className="text-white text-lg font-medium drop-shadow-lg">Video with Applied Style</p>
                  <p className="text-white/80 text-sm mt-2">
                    {selectedPaletteData?.name} • {selectedEffects.length} effects
                  </p>
                </div>
                
                {/* Style overlay elements */}
                <div className="absolute top-4 left-4 right-4">
                  <div className={`bg-white/20 backdrop-blur-sm rounded-lg p-3 transition-all duration-300 ${
                    selectedEffects.includes('gradientOverlay') ? 'bg-gradient-to-r from-white/30 to-transparent' : ''
                  }`}>
                    <h4 className="text-white font-semibold drop-shadow">Sample Title Overlay</h4>
                    <p className="text-white/90 text-sm">Effects: {selectedEffects.join(', ') || 'None'}</p>
                  </div>
                </div>

                {/* Effect indicators */}
                <div className="absolute bottom-4 right-4 flex flex-col gap-1">
                  {selectedEffects.map((effect) => (
                    <span key={effect} className="bg-black/50 text-white text-xs px-2 py-1 rounded">
                      ✓ {effect.replace(/([A-Z])/g, ' $1').trim()}
                    </span>
                  ))}
                </div>

                {/* Color palette preview */}
                {selectedPaletteData && (
                  <div className="absolute bottom-4 left-4 flex gap-1">
                    {selectedPaletteData.colors.map((color, index) => (
                      <div
                        key={index}
                        className="w-4 h-4 rounded border border-white/50"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Style Controls */}
              <div className="mt-6 grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium mb-2">Transition Style</Label>
                  <Select value={transitionStyle} onValueChange={setTransitionStyle}>
                    <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fade">Fade</SelectItem>
                      <SelectItem value="slide">Slide</SelectItem>
                      <SelectItem value="zoom">Zoom</SelectItem>
                      <SelectItem value="blur">Blur</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-sm font-medium mb-2">Animation Speed</Label>
                  <Select value={animationSpeed} onValueChange={setAnimationSpeed}>
                    <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="slow">Slow</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="fast">Fast</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Style Options */}
        <div className="space-y-6">
          {/* Color Palette */}
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Color Palette</h3>
              <div className="grid grid-cols-2 gap-3">
                {colorPalettes.map((palette) => (
                  <button
                    key={palette.id}
                    onClick={() => applyColorPalette(palette.id)}
                    className={`p-3 rounded-lg border-2 transition-colors ${
                      selectedPalette === palette.id
                        ? 'border-primary bg-primary/10'
                        : 'border-[hsl(var(--surface-light))] hover:border-primary'
                    }`}
                  >
                    <div className="flex space-x-1 mb-2">
                      {palette.colors.map((color, index) => (
                        <div
                          key={index}
                          className="w-4 h-4 rounded"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                    <span className="text-sm">{palette.name}</span>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Visual Effects */}
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Visual Effects</h3>
              <div className="space-y-3">
                {visualEffects.map((effect) => (
                  <label key={effect.id} className="flex items-start space-x-3 cursor-pointer">
                    <Checkbox
                      checked={selectedEffects.includes(effect.id)}
                      onCheckedChange={(checked) => 
                        handleEffectChange(effect.id, checked as boolean)
                      }
                      className="mt-0.5"
                    />
                    <div>
                      <div className="font-medium">{effect.name}</div>
                      <div className="text-sm text-slate-400">{effect.description}</div>
                    </div>
                  </label>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Style Templates */}
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Style Templates</h3>
              <div className="space-y-2">
                {styleTemplates.map((template) => (
                  <button
                    key={template.id}
                    onClick={() => setSelectedTemplate(template.id)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${
                      selectedTemplate === template.id
                        ? 'bg-primary/20 border border-primary/30'
                        : 'bg-[hsl(var(--surface-light))] hover:bg-primary/10'
                    }`}
                  >
                    <div className="font-medium">{template.name}</div>
                    <div className="text-sm text-slate-400">{template.description}</div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <Button
          variant="ghost"
          onClick={onPrevious}
          disabled={isFirstStep}
          className="text-slate-400 hover:text-white"
        >
          Back
        </Button>
        <Button
          onClick={handleNext}
          className="bg-primary hover:bg-primary/90"
        >
          Continue to Voiceover
        </Button>
      </div>
    </div>
  );
}
