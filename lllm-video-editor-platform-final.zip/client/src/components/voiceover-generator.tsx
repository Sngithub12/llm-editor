import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Play, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface VoiceoverGeneratorProps {
  workflowType: string;
  projectData: any;
  onStepData: (stepId: string, data: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isFirstStep: boolean;
  isLastStep: boolean;
}

const voices = [
  { id: 'sarah', name: 'Sarah', type: 'Professional Female', language: 'English' },
  { id: 'michael', name: 'Michael', type: 'Deep Male', language: 'English' },
  { id: 'emma', name: 'Emma', type: 'Friendly Female', language: 'English' },
  { id: 'david', name: 'David', type: 'Corporate Male', language: 'English' },
];

const languages = [
  { code: 'en-US', name: 'English (US)' },
  { code: 'en-GB', name: 'English (UK)' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'zh', name: 'Chinese' },
];

export default function VoiceoverGenerator({ 
  workflowType,
  projectData, 
  onStepData, 
  onNext, 
  onPrevious, 
  isFirstStep 
}: VoiceoverGeneratorProps) {
  const [selectedVoice, setSelectedVoice] = useState('sarah');
  const [scriptText, setScriptText] = useState('');
  const [speed, setSpeed] = useState([1]);
  const [pitch, setPitch] = useState([0]);
  const [emphasis, setEmphasis] = useState('normal');
  const [language, setLanguage] = useState('en-US');
  const [volume, setVolume] = useState([75]);
  const [audioPath, setAudioPath] = useState<string | null>(null);

  const { toast } = useToast();

  useEffect(() => {
    // Initialize script text from previous steps
    const script = projectData.script?.content || 
                  projectData.subtitles?.subtitles?.map((s: any) => s.text).join(' ') ||
                  'Welcome to our AI video editing platform. Create stunning videos with ease using our professional tools. Transform your ideas into engaging visual content in just minutes.';
    setScriptText(script);

    if (projectData.voiceover) {
      setSelectedVoice(projectData.voiceover.voiceId || 'sarah');
      setSpeed([projectData.voiceover.speed || 1]);
      setPitch([projectData.voiceover.pitch || 0]);
      setEmphasis(projectData.voiceover.emphasis || 'normal');
      setLanguage(projectData.voiceover.language || 'en-US');
      setAudioPath(projectData.voiceover.audioPath || null);
    }
  }, [projectData]);

  const generateVoiceoverMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/generate-voiceover', {
        script: scriptText,
        voiceId: selectedVoice,
        speed: speed[0],
        pitch: pitch[0],
        language,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setAudioPath(data.audioPath);
      toast({
        title: "Voiceover generated",
        description: "Your AI voiceover has been created successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation failed",
        description: error instanceof Error ? error.message : "Failed to generate voiceover",
        variant: "destructive",
      });
    },
  });

  const handleVoicePreview = (voiceId: string) => {
    toast({
      title: "Voice preview",
      description: `Playing preview for ${voices.find(v => v.id === voiceId)?.name}`,
    });
  };

  const handleNext = () => {
    if (!audioPath && workflowType === 'generate') {
      toast({
        title: "Voiceover required",
        description: "Please generate a voiceover before continuing.",
        variant: "destructive",
      });
      return;
    }

    onStepData('voiceover', {
      voiceId: selectedVoice,
      speed: speed[0],
      pitch: pitch[0],
      emphasis,
      language,
      audioPath,
      scriptText,
    });
    onNext();
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-4">AI Voiceover</h2>
        <p className="text-slate-300">Add professional AI-generated voiceover to your video</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Audio Preview */}
        <div className="lg:col-span-2">
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Voice Preview</h3>
              
              {/* Audio Waveform Visualization */}
              <Card className="bg-black p-6 mb-4">
                <div className="flex items-center justify-center h-32">
                  <div className="flex items-end space-x-1">
                    {/* Animated waveform bars */}
                    {Array.from({ length: 20 }, (_, i) => (
                      <div
                        key={i}
                        className={`w-2 bg-primary rounded waveform-bar`}
                        style={{ 
                          height: `${Math.random() * 60 + 20}px`,
                          animationDelay: `${i * 0.1}s`
                        }}
                      />
                    ))}
                  </div>
                </div>
              </Card>

              {/* Audio Controls */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-4">
                  <Button
                    size="lg"
                    className="w-12 h-12 rounded-full bg-primary hover:bg-primary/90"
                    disabled={!audioPath}
                  >
                    <Play className="h-5 w-5 text-white" />
                  </Button>
                  <span className="text-sm text-slate-400">0:00 / 2:30</span>
                </div>
                <div className="flex items-center space-x-2">
                  <VolumeX className="h-4 w-4 text-slate-400" />
                  <Slider
                    value={volume}
                    onValueChange={setVolume}
                    max={100}
                    step={1}
                    className="w-24"
                  />
                  <Volume2 className="h-4 w-4 text-slate-400" />
                </div>
              </div>

              {/* Script Text */}
              <div>
                <Label htmlFor="script" className="text-lg font-semibold mb-3">Script Text</Label>
                <Textarea
                  id="script"
                  value={scriptText}
                  onChange={(e) => setScriptText(e.target.value)}
                  rows={8}
                  placeholder="Enter your script text here..."
                  className="bg-[hsl(var(--surface-light))] border-[hsl(var(--surface-light))] focus:border-primary resize-none"
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Voice Settings */}
        <div className="space-y-6">
          {/* Voice Selection */}
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Voice Selection</h3>
              <div className="space-y-3">
                {voices.map((voice) => (
                  <div
                    key={voice.id}
                    className={`p-3 rounded-lg cursor-pointer transition-colors ${
                      selectedVoice === voice.id
                        ? 'bg-primary/20 border border-primary/30'
                        : 'bg-[hsl(var(--surface-light))] hover:bg-primary/10'
                    }`}
                    onClick={() => setSelectedVoice(voice.id)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">{voice.name}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleVoicePreview(voice.id);
                        }}
                        className="text-primary hover:text-primary/80"
                      >
                        <Play className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="text-sm text-slate-400">
                      {voice.type} • {voice.language}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Voice Parameters */}
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Voice Parameters</h3>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium mb-2">Speed</Label>
                  <Slider
                    value={speed}
                    onValueChange={setSpeed}
                    min={0.5}
                    max={2}
                    step={0.1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-1">
                    <span>0.5x</span>
                    <span>1x</span>
                    <span>2x</span>
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm font-medium mb-2">Pitch</Label>
                  <Slider
                    value={pitch}
                    onValueChange={setPitch}
                    min={-10}
                    max={10}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-1">
                    <span>Low</span>
                    <span>Normal</span>
                    <span>High</span>
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2">Emphasis</Label>
                  <Select value={emphasis} onValueChange={setEmphasis}>
                    <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="strong">Strong</SelectItem>
                      <SelectItem value="moderate">Moderate</SelectItem>
                      <SelectItem value="reduced">Reduced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Language Options */}
          <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Language & Accent</h3>
              <div className="space-y-3">
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Button
                  onClick={() => generateVoiceoverMutation.mutate()}
                  disabled={generateVoiceoverMutation.isPending || !scriptText.trim()}
                  className="w-full bg-primary hover:bg-primary/90"
                >
                  {generateVoiceoverMutation.isPending ? "Generating..." : "Generate Voiceover"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <Button
          variant="ghost"
          onClick={onPrevious}
          disabled={isFirstStep}
          className="text-slate-400 hover:text-white"
        >
          Back
        </Button>
        <Button
          onClick={handleNext}
          className="bg-primary hover:bg-primary/90"
        >
          Continue to Export
        </Button>
      </div>
    </div>
  );
}
