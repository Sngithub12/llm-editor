import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { CloudUpload, X, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface VideoUploadProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadComplete: (filePath: string) => void;
}

export default function VideoUpload({ isOpen, onClose, onUploadComplete }: VideoUploadProps) {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('video', file);
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Upload failed' }));
        throw new Error(errorData.message || 'Upload failed');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Upload successful",
        description: "Your video has been uploaded successfully.",
      });
      onUploadComplete(data.path);
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload video",
        variant: "destructive",
      });
    },
  });

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('video/')) {
      toast({
        title: "Invalid file type",
        description: "Please select a video file.",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 500 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select a video file smaller than 500MB.",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
  };

  const handleUpload = () => {
    if (selectedFile) {
      uploadMutation.mutate(selectedFile);
    }
  };

  const handleClose = () => {
    setSelectedFile(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold mb-2">Upload Your Video</DialogTitle>
          <p className="text-slate-300">Select a video file to start editing</p>
        </DialogHeader>

        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-12 text-center transition-colors cursor-pointer ${
            dragOver
              ? 'border-primary bg-primary/10'
              : 'border-[hsl(var(--surface-light))] hover:border-primary'
          }`}
        >
          {selectedFile ? (
            <div className="space-y-4">
              <CheckCircle className="h-16 w-16 text-accent mx-auto" />
              <div>
                <p className="text-lg font-medium">Video selected: {selectedFile.name}</p>
                <p className="text-sm text-slate-400">
                  Size: {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <CloudUpload className="h-16 w-16 text-slate-400 mx-auto" />
              <div>
                <p className="text-lg mb-2">Drop your video here or click to browse</p>
                <p className="text-sm text-slate-400">Supports MP4, MOV, AVI (Max 500MB)</p>
              </div>
            </div>
          )}
          
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
            className="hidden"
          />
        </div>

        <div className="flex justify-end space-x-4 mt-6">
          <Button variant="ghost" onClick={handleClose} className="text-slate-300 hover:text-white">
            Cancel
          </Button>
          <Button
            onClick={handleUpload}
            disabled={!selectedFile || uploadMutation.isPending}
            className="bg-primary hover:bg-primary/90"
          >
            {uploadMutation.isPending ? "Uploading..." : "Continue"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
