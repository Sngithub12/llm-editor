import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Download, CheckCircle, Settings, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";

interface VideoExportProps {
  workflowType: string;
  projectData: any;
  onStepData: (stepId: string, data: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isFirstStep: boolean;
  isLastStep: boolean;
}

export default function VideoExport({ 
  workflowType,
  projectData, 
  onStepData, 
  onPrevious, 
  isFirstStep 
}: VideoExportProps) {
  const [quality, setQuality] = useState('1080p');
  const [format, setFormat] = useState('mp4');
  const [frameRate, setFrameRate] = useState(30);
  const [compression, setCompression] = useState('standard');
  const [exportProgress, setExportProgress] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const exportMutation = useMutation({
    mutationFn: async () => {
      const exportData = {
        projectId: Date.now(),
        workflowType: workflowType || "generate",
        script: projectData.script,
        inputVideoPath: projectData.uploadedVideoPath,
        subtitles: projectData.subtitles?.subtitles,
        styleSettings: projectData.style,
        audioPath: projectData.voiceover?.audioPath,
        exportSettings: {
          quality,
          format,
          frameRate,
          compression,
        },
      };

      const response = await apiRequest('POST', '/api/export-video', exportData);
      return response.json();
    },
    onSuccess: (data) => {
      setExportComplete(true);
      setDownloadUrl(data.videoPath);
      toast({
        title: "Export complete",
        description: "Your video has been processed successfully!",
      });
    },
    onError: (error) => {
      setIsExporting(false);
      setExportProgress(0);
      toast({
        title: "Export failed",
        description: error instanceof Error ? error.message : "Failed to export video",
        variant: "destructive",
      });
    },
  });

  const handleExport = () => {
    setIsExporting(true);
    setExportProgress(0);
    exportMutation.mutate();
  };

  const handleDownload = () => {
    if (downloadUrl) {
      const filename = downloadUrl.split('/').pop() || 'LLLM_Video_Export.mp4';
      
      // Create a download link element
      const downloadLink = document.createElement('a');
      downloadLink.href = `/api/download/${filename}`;
      downloadLink.download = filename;
      downloadLink.style.display = 'none';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      
      toast({
        title: "Download started",
        description: `Your video "${filename}" is being downloaded to your device.`,
      });
    }
  };

  const startNewProject = () => {
    setLocation("/");
  };

  // Simulate export progress
  useEffect(() => {
    if (isExporting && !exportComplete) {
      const interval = setInterval(() => {
        setExportProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          return prev + Math.random() * 10;
        });
      }, 500);

      return () => clearInterval(interval);
    }
  }, [isExporting, exportComplete]);

  const processingSteps = [
    { id: 'processing', label: 'Video processing complete', completed: true },
    { id: 'subtitles', label: 'Subtitles embedded', completed: true },
    { id: 'style', label: 'Style effects applied', completed: true },
    { id: 'voiceover', label: 'Voiceover synchronized', completed: true },
    { id: 'export', label: 'Finalizing export...', completed: exportComplete },
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-4">Export Video</h2>
        <p className="text-slate-300">Configure export settings and download your finished video</p>
      </div>

      {/* Video Preview */}
      <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))] mb-8">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Final Video Preview</h3>
          <div className="video-preview bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 border-2 border-accent/30">
            <div className="text-center">
              <div className="h-16 w-16 bg-gradient-to-br from-accent to-primary rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse shadow-lg">
                <div className="h-0 w-0 border-l-[16px] border-l-white border-y-[12px] border-y-transparent ml-1"></div>
              </div>
              <p className="text-white text-lg font-medium drop-shadow-lg">Your Completed Video</p>
              <p className="text-white/70">Ready for download • {quality} quality</p>
              
              {/* Progress indicator for export */}
              {isExporting && (
                <div className="mt-4 w-48 mx-auto">
                  <div className="bg-white/20 rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-accent h-full transition-all duration-500 rounded-full"
                      style={{ width: `${exportProgress}%` }}
                    />
                  </div>
                  <p className="text-white/80 text-sm mt-2">Processing... {Math.round(exportProgress)}%</p>
                </div>
              )}
            </div>
            
            {/* Applied effects indicators */}
            <div className="absolute top-4 right-4 space-y-2">
              {projectData.subtitles && (
                <div className="bg-accent/90 text-white text-xs px-3 py-1 rounded-full border border-white/20 flex items-center gap-2">
                  <span>🎭</span> Subtitles ({projectData.subtitles.languages?.length || 1} languages)
                </div>
              )}
              {projectData.style && (
                <div className="bg-primary/90 text-white text-xs px-3 py-1 rounded-full border border-white/20 flex items-center gap-2">
                  <span>🎨</span> Style ({projectData.style.visualEffects?.length || 0} effects)
                </div>
              )}
              {projectData.voiceover && (
                <div className="bg-secondary/90 text-white text-xs px-3 py-1 rounded-full border border-white/20 flex items-center gap-2">
                  <span>🎙️</span> AI Voiceover
                </div>
              )}
            </div>

            {/* Export quality badge */}
            <div className="absolute top-4 left-4">
              <div className="bg-black/60 text-white text-sm px-3 py-2 rounded-lg border border-white/20">
                <div className="font-semibold">{quality} • {format.toUpperCase()}</div>
                <div className="text-xs text-white/80">{frameRate} FPS</div>
              </div>
            </div>

            {/* Download indicator */}
            {exportComplete && (
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                <div className="bg-accent/90 text-white px-4 py-2 rounded-full border border-white/20 flex items-center gap-2 animate-bounce">
                  <span>⬇️</span> Ready to Download
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Export Settings */}
        <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Export Settings</h3>
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-medium mb-2">Video Quality</Label>
                <Select value={quality} onValueChange={setQuality}>
                  <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="4K">4K (3840x2160) - Best Quality</SelectItem>
                    <SelectItem value="1080p">1080p (1920x1080) - High Quality</SelectItem>
                    <SelectItem value="720p">720p (1280x720) - Good Quality</SelectItem>
                    <SelectItem value="480p">480p (854x480) - Standard Quality</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2">Format</Label>
                <Select value={format} onValueChange={setFormat}>
                  <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mp4">MP4 (Recommended)</SelectItem>
                    <SelectItem value="mov">MOV</SelectItem>
                    <SelectItem value="avi">AVI</SelectItem>
                    <SelectItem value="webm">WebM</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2">Frame Rate</Label>
                <Select value={frameRate.toString()} onValueChange={(value) => setFrameRate(parseInt(value))}>
                  <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 FPS</SelectItem>
                    <SelectItem value="60">60 FPS</SelectItem>
                    <SelectItem value="24">24 FPS</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2">Compression</Label>
                <Select value={compression} onValueChange={setCompression}>
                  <SelectTrigger className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="high">High (Smaller file)</SelectItem>
                    <SelectItem value="low">Low (Larger file)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Export Status */}
        <Card className="bg-[hsl(var(--surface))] border-[hsl(var(--surface-light))]">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Export Status</h3>
            
            <div className="space-y-4">
              {/* Processing Steps */}
              {processingSteps.map((step) => (
                <div key={step.id} className="flex items-center space-x-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                    step.completed ? 'bg-accent' : 'bg-primary processing-spinner'
                  }`}>
                    {step.completed ? (
                      <CheckCircle className="h-4 w-4 text-white" />
                    ) : (
                      <Settings className="h-4 w-4 text-white" />
                    )}
                  </div>
                  <span className={step.completed ? 'text-white' : 'text-slate-300'}>
                    {step.label}
                  </span>
                </div>
              ))}
            </div>

            {/* Progress Bar */}
            {isExporting && (
              <div className="mt-6">
                <div className="flex justify-between text-sm mb-2">
                  <span>Export Progress</span>
                  <span>{Math.round(exportProgress)}%</span>
                </div>
                <Progress value={exportProgress} className="w-full" />
              </div>
            )}

            {/* File Info */}
            <Card className="mt-6 bg-[hsl(var(--surface-light))]">
              <CardContent className="p-4">
                <h4 className="font-medium mb-2">Output File</h4>
                <div className="text-sm text-slate-300 space-y-1">
                  <div>Name: LLLM_Video_Export.{format}</div>
                  <div>Size: ~45.2 MB</div>
                  <div>Duration: 2:30</div>
                  <div>Resolution: {quality === '4K' ? '3840x2160' : quality === '1080p' ? '1920x1080' : quality === '720p' ? '1280x720' : '854x480'}</div>
                </div>
              </CardContent>
            </Card>
          </CardContent>
        </Card>
      </div>

      {/* Export Actions */}
      <div className="mt-8 text-center">
        {!isExporting && !exportComplete && (
          <Button
            onClick={handleExport}
            className="bg-accent hover:bg-accent/90 text-white py-4 px-12 rounded-lg font-medium text-lg"
          >
            <Settings className="mr-2 h-5 w-5" />
            Start Export
          </Button>
        )}

        {isExporting && !exportComplete && (
          <Button
            disabled
            className="bg-accent/50 text-white py-4 px-12 rounded-lg font-medium text-lg"
          >
            <div className="processing-spinner mr-2 h-5 w-5" />
            Processing...
          </Button>
        )}

        {exportComplete && (
          <Button
            onClick={handleDownload}
            className="bg-accent hover:bg-accent/90 text-white py-4 px-12 rounded-lg font-medium text-lg"
          >
            <Download className="mr-2 h-5 w-5" />
            Download Video
          </Button>
        )}
        
        <div className="mt-4 text-sm text-slate-400">
          {isExporting && !exportComplete && "Your video is being processed..."}
          {exportComplete && "Your video is ready for download!"}
          {!isExporting && !exportComplete && "Configure settings and start export"}
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <Button
          variant="ghost"
          onClick={onPrevious}
          disabled={isFirstStep}
          className="text-slate-400 hover:text-white"
        >
          Back
        </Button>
        <Button
          onClick={startNewProject}
          variant="outline"
          className="border-primary text-primary hover:bg-primary/10"
        >
          <Plus className="mr-2 h-4 w-4" />
          New Project
        </Button>
      </div>
    </div>
  );
}
